### Project Title

**Author**

#### Executive summary

#### Rationale
Why should anyone care about this question?

#### Research Question
What are you trying to answer?

#### Data Sources
What data will you use to answer you question?

#### Methodology
What methods are you using to answer the question?

#### Results
What did your research find?

#### Next steps
What suggestions do you have for next steps?

#### Outline of project

- [Link to notebook 1]()
- [Link to notebook 2]()
- [Link to notebook 3]()


##### Contact and Further Information